TEST_GROUP_TITLE = "Тестовая группа"

TEST_GROUP_SLUG = "TestSlug"

TEST_GROUP_DESCRIPTION = "Тестовое описание"

TEST_POST_TEXT = "Тестовый текст"

TEST_HEADING = "Тестовый заголовок"

TEST_EDITED_POST_TEXT = "Отредактированный текст"

TEST_AUTHOR_USERNAME = "TestAuthor"

TEST_AUTH_USER = "TestAuthUser"

TEST_COMMENT = "TestComment"

NUMBER_OF_TEST_POSTS = 15

TEST_IMAGE = (
    b'\x47\x49\x46\x38\x39\x61\x02\x00'
    b'\x01\x00\x80\x00\x00\x00\x00\x00'
    b'\xFF\xFF\xFF\x21\xF9\x04\x00\x00'
    b'\x00\x00\x00\x2C\x00\x00\x00\x00'
    b'\x02\x00\x01\x00\x00\x02\x02\x0C'
    b'\x0A\x00\x3B'
)
